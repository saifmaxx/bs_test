<style>   
    .active_row { 
        background: #dcf3d5 !important;
    }
</style>
<div class="row wrapper border-bottom white-bg page-heading">    
    <div class="col-lg-10">  
        <h2>Category Tree</h2>    
    </div>
</div>
<div class="wrapper wrapper-content animated fadeInRight">    
    <div class="row">      
        <div class="col-lg-12">   
            <div class="ibox float-e-margins">     
                <div class="ibox-title">                
                    <h5>Category Tree               
                        <small class="alert-danger"></small>    
                    </h5>                  
                    <div class="ibox-tools">       
                        <a class="collapse-link">          
                            <i class="fa fa-chevron-up"></i>          
                        </a>                 
                    </div>          
                </div>              
                <div class="ibox-content">        
                    
					<?php

    function display_children($parent_id, $level) {
        $ci = & get_instance();
        // retrieve all children
        $sql = "SELECT  c.Id, c.Name, m.categoryId, m.ParentcategoryId, x.count_row 
		FROM category c
		JOIN catetory_relations m ON c.Id = m.categoryId
		LEFT OUTER JOIN (SELECT ParentcategoryId, COUNT(*) AS count_row FROM catetory_relations GROUP BY ParentcategoryId) x ON c.Id = x.ParentcategoryId 
		WHERE m.ParentcategoryId = $parent_id ";


        $result = $ci->db->query($sql)->result();

        echo "<ul>";
        if (!empty($result)) {
            foreach ($result as $row) {
                 /*echo '<pre>';
                  print_r($row);
                  //exit; */
                if ($row->count_row > 0) {
                    echo '<li><span>&nbsp; ' . $row->Name .'-'.$row->count_row. '</span>';
                    display_children($row->categoryId, $level + 1);
                    echo "</li>";
                } else {
                    echo '<li><span>&nbsp;' . $row->Name .'-'.$row->count_row. '
						</span>';
                    echo "</li>";
                }
            }
        }
        echo "</ul>";
    }

    echo '<div><div class="bg-font-normal" style = "width:90%;">
			<ul id="red" class="treeview-red">
			<li><span class="folder"><i class = "fa fa-book tree-toogle"></i> &nbsp; Category</span>';
		display_children(1, 1);
    echo '</li></ul> ';
    echo '</div></div>';
    ?>
					
					
					
					
                </div>      
            </div>      
        </div> 
    </div>
</div>

<script type="text/javascript" src="<?php echo base_url(); ?>resources/template/js/jquery-1.9.1.js"></script>
<link type="text/css" href="<?php echo base_url(); ?>resources/template/css/jquery.treeview.css" rel="stylesheet"/>
<script type="text/javascript" src="<?php echo base_url(); ?>resources/template/js/jquery.treeview.js"></script>
<script type="text/javascript">
    //$(document).ready(function () {
 
        $("#red").treeview({
            animated: "fast",
            collapsed: false,
            unique: true,
            //persist: "cookie",
            toggle: function () {
                window.console && console.log("%o was toggled", this);
            }
        });

   // });
</script>
