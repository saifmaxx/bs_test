<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Admin extends CI_Controller {

    function __construct() {
        parent::__construct();
        if (!($this->session->userdata("user_logged_in"))) {
            redirect('auth/index', 'refresh');
        }
        $this->load->library(array('admin_template'));
    }

    public function index() {
        $data['content_view_page'] = 'admin/categories';
        $data['categories'] = $this->db->query('SELECT c.Name,count(DISTINCT i.Stock) ttl 
												FROM item_category_relations ci 
												JOIN category c ON c.Id = ci.categoryId 
												JOIN item i ON ci.ItemNumber = i.Number 
												GROUP BY c.ID ORDER BY ttl DESC ')->result();
        $this->admin_template->display($data);
    }
	
	
	public function tree() {
        $data['content_view_page'] = 'admin/tree';
        $this->admin_template->display($data);
    }

}
