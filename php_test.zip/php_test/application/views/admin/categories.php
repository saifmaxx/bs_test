<style>   
    .active_row { 
        background: #dcf3d5 !important;
    }
</style>
<div class="row wrapper border-bottom white-bg page-heading">    
    <div class="col-lg-10">  
        <h2>Category</h2>    
    </div>
</div>
<div class="wrapper wrapper-content animated fadeInRight">    
    <div class="row">      
        <div class="col-lg-12">   
            <div class="ibox float-e-margins">     
                <div class="ibox-title">                
                    <h5>Category List               
                        <small class="alert-danger"></small>    
                    </h5>                  
                    <div class="ibox-tools">       
                        <a class="collapse-link">          
                            <i class="fa fa-chevron-up"></i>          
                        </a>                 
                    </div>          
                </div>              
                <div class="ibox-content">        
                    <table class="table table-striped table-bordered table-hover dataTables-example">              
                        <thead>                    
                            <tr>                         
                                <th>SL</th>
                                <th>Category Name</th>
                                <th>Total Items</th>                 
                            </tr>              
                        </thead>            
                        <tbody>      
                            <?php
                            if (!empty($categories)) {
                                $sl = 1;
                                foreach ($categories as $row) {
                                    ?>       
                                    <tr>      
                                        <td><?php echo $sl++; ?></td>                           
                                        <td><?php echo $row->Name; ?></td>                                  
                                        <td><?php echo $row->ttl  ; ?></td>           
                                                                  
                                    </tr>                          
                                    <?php
                                }
                            }
                            ?></tbody>          
                        <tfoot>       
                        </tfoot>               
                    </table>   
                </div>      
            </div>      
        </div> 
    </div>
</div>