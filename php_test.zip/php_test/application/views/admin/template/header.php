<nav class="navbar-default navbar-static-side" role="navigation">
            <div class="sidebar-collapse">
                <ul class="nav metismenu" id="side-menu">
                    <li class="nav-header">
    
                    </li>
                    <li>
                        <a href="<?php echo site_url('admin/index'); ?>"><i class="fa fa-diamond"></i> <span class="nav-label">Categories</span></a>
                    </li>
                    <li>
                        <a href="<?php echo site_url('admin/tree'); ?>"><i class="fa fa-diamond"></i> <span class="nav-label">Tree</span></a>
                    </li>

                </ul>

            </div>
        </nav>