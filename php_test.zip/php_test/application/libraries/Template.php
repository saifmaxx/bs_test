<?php

class Template {

    protected $_ci;

    function __construct() {

        $this->_ci = &get_instance();
    }

    function display($data = null) {
        $data['pageTitle'] = (isset($data['pageTitle']) == '') ? 'XESSTECH .::. Welcome' : $data['pageTitle'];
        $data['_content'] = $this->_ci->load->view((isset($data['content_view_page']) == '') ? 'template/home' : $data['content_view_page'], $data, true);
        $this->_ci->load->view('template/template.php', $data);
    }

}

?>